from django.urls import path
from .views import DetailMovie,MovieListCreateView
app_name = 'movie'
urlpatterns = [
    path('api/movie/<str:code>/', DetailMovie.as_view(), name='movie-detail'),
    path('api/movie/creat', MovieListCreateView.as_view(), name='movie-list-create'),
]
