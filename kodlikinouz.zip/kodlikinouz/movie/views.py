from rest_framework.generics import RetrieveAPIView ,ListCreateAPIView
from .models import Movie
from .serializers import MovieSerializer

# Create your views here.
class MovieListCreateView(ListCreateAPIView):
    queryset = Movie.objects.all()
    serializer_class = MovieSerializer
class DetailMovie(RetrieveAPIView):
    queryset =  Movie.objects.all()
    serializer_class = MovieSerializer
    lookup_field = 'code'