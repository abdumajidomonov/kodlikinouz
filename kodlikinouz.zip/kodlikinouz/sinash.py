import requests

# API endpoint manzili
url = 'http://127.0.0.1:8000/api/movie/creat'

# POST so'rovi uchun ma'lumotlar
data = {
    'name': 'Film nomi',
    'code': 123,
    'message_id': 'Some message'
}

# POST so'rovi yuborish
response = requests.post(url, json=data)

# POST so'rovi natijasini tekshirish
if response.status_code == 201:  # 201 Created
    print('Film muvaffaqiyatli qo\'shildi!')
elif response.status_code == 400:  # 400 Bad Request
    print('So\'rovni yuborishda xatolik yuz berdi. Ma\'lumotlarni tekshirib qaytadan urinib ko\'ring.')
else:
    print(f'Serverdan qaytarilgan xato: {response.status_code}')